"""Spec-aware Girard reduction (env-gated, default OFF).

Precomputes a per-layer linear "spec direction" F_t at setup time, then
uses ||F_t @ Gc[:, i]||_1 as a ranking heuristic in Girard generator
reduction (replacing the standard column-norm).

DESIGN INTENT vs CROWN
----------------------
This is NOT CROWN-style backward bound propagation:
- We compute a single linear functional F_t, not (lb, ub) bounds.
- Triangle slope λ at each ReLU is FIXED (taken from cheap interval
  bounds), not optimized via gradient descent.
- F_t is used ONLY for scoring in Girard reduction. The reduction is
  sound for any subset choice (Girard accumulates dropped columns into
  diagonal box generators). We never refine bounds with F_t.

The reverse-order traversal of weights is layer-traversal direction
only; arithmetically it is the same matrix product as CROWN's spec
direction, but the USE is entirely different (heuristic ranking vs
verification step).

Soundness
---------
Girard reduction's soundness does not depend on the scoring criterion.
Any subset of generators can be dropped and the result is a valid
over-approximation of the original HZ. So this module cannot violate
soundness; it only changes ranking heuristic. Worst case: the F_t is
poorly computed (e.g., unsupported layer breaks the chain) and the
scoring is no worse than column-norm.

API
---
- ``precompute_spec_F(net, assert_layer, before, device, dtype)`` —
  call at setup; returns ``Dict[layer_id, F_t]``.
- ``set_context(F_by_layer)`` / ``clear_context()`` — set/clear the
  thread-local context.
- ``set_current_layer(layer_id)`` — call before each reduce.
- ``get_F_for_current()`` — read F for currently-set layer.
- ``is_enabled()`` — env knob check.
"""
from __future__ import annotations
import os
import threading
from typing import Any, Dict, Optional

import torch


_CTX = threading.local()


def is_enabled() -> bool:
    """Whether ACT_HZ_SPEC_AWARE_GIRARD env knob is on."""
    return os.environ.get("ACT_HZ_SPEC_AWARE_GIRARD", "0") == "1"


def set_context(F_by_layer: Dict[int, torch.Tensor]) -> None:
    _CTX.F_by_layer = F_by_layer
    _CTX.current_layer = None


def set_current_layer(layer_id: int) -> None:
    _CTX.current_layer = layer_id


def get_F_for_current() -> Optional[torch.Tensor]:
    F_by = getattr(_CTX, "F_by_layer", None)
    cur = getattr(_CTX, "current_layer", None)
    if F_by is None or cur is None:
        return None
    return F_by.get(cur)


def get_F_for(layer_id: int) -> Optional[torch.Tensor]:
    F_by = getattr(_CTX, "F_by_layer", None)
    if F_by is None:
        return None
    return F_by.get(layer_id)


def clear_context() -> None:
    _CTX.F_by_layer = None
    _CTX.current_layer = None


def precompute_spec_F(
    net: Any,
    assert_layer: Any,
    before: Dict[int, Any],
    device: torch.device,
    dtype: torch.dtype,
    *,
    debug: bool = False,
) -> Dict[int, torch.Tensor]:
    """Compute F_t for each layer by reverse-order matrix chain.

    Supported layer kinds in the chain (MVP):
      - DENSE: F_in = F_out @ W
      - RELU:  F_in = F_out * λ_i per neuron (triangle slope from before[L.id])
      - LRELU: F_in = F_out * λ_i per neuron (triangle slope)
      - BIAS:  F unchanged
      - SCALE: F_in = F_out * a per channel
      - INPUT / INPUT_SPEC / ASSERT: skip
    Any other layer stops the chain — earlier layers have no F entry,
    and the scoring at those layers falls back to standard column-norm.

    Returns a dict {layer_id: F} where F_t has shape (k, dim_at_layer_t_output)
    if layer_id is the output of a supported layer; (k, dim_at_layer_t_input)
    for the next layer below in reverse iteration.

    Convention: ``F_by_layer[L.id]`` is the spec direction APPLIED TO the
    output of layer L, i.e. the same dim as the HZ after that layer.

    On any error, returns whatever was computed so far.
    """
    C_raw = assert_layer.params.get("C")
    if C_raw is None:
        return {}
    try:
        C = C_raw.to(device=device, dtype=dtype)
    except Exception:
        return {}
    # C may be (B*M, n_out); MVP assumes B=1 (per-lane call site)
    if C.dim() != 2:
        return {}

    # F starts as the spec direction at OUTPUT of ASSERT (= spec direction
    # at output of the layer before ASSERT). We walk layers in reverse,
    # storing F BEFORE updating it so F_by_layer[L.id] is "spec direction
    # at output of L = input of L's successor".
    F: Optional[torch.Tensor] = C
    F_by_layer: Dict[int, torch.Tensor] = {}

    layers_rev = list(reversed(list(net.layers)))
    for L in layers_rev:
        kind = getattr(L, "kind", "") or ""
        kind_s = kind if isinstance(kind, str) else str(kind)
        kind_s = kind_s.upper().split(".")[-1]

        # ASSERT is the spec endpoint; just skip but keep F.
        if kind_s == "ASSERT":
            continue

        # Store F for this layer's OUTPUT before updating for next iteration.
        # We only store if F's last dim matches a plausible HZ dim.
        if F is not None:
            F_by_layer[L.id] = F.clone()

        # Now derive F_in (spec direction at input of layer L) from F (output).
        try:
            if kind_s == "DENSE":
                W_raw = L.params.get("weight")
                if W_raw is None:
                    F = None
                    break
                W = W_raw.to(device=device, dtype=dtype)
                # W: (out, in). F: (k, out). F_in = F @ W → (k, in)
                if F.shape[1] != W.shape[0]:
                    if debug:
                        print(f"[spec_aware] DENSE shape mismatch at L{L.id}: "
                              f"F{tuple(F.shape)} vs W{tuple(W.shape)}")
                    F = None
                    break
                F = F @ W
            elif kind_s == "BIAS":
                # y = x + c; F_in = F_out (additive shift doesn't affect direction)
                pass
            elif kind_s == "SCALE":
                a_raw = L.params.get("a")
                if a_raw is None:
                    pass
                else:
                    a = a_raw.to(device=device, dtype=dtype).flatten()
                    if a.numel() != F.shape[1]:
                        F = None
                        break
                    F = F * a.unsqueeze(0)
            elif kind_s == "RELU":
                # F_in = F * λ per neuron, where λ depends on (lb, ub)
                bnds_fact = before.get(L.id)
                if bnds_fact is None or not hasattr(bnds_fact, "bounds"):
                    F = None
                    break
                lb = bnds_fact.bounds.lb.flatten().to(device=device, dtype=dtype)
                ub = bnds_fact.bounds.ub.flatten().to(device=device, dtype=dtype)
                if lb.numel() != F.shape[1]:
                    F = None
                    break
                lam = torch.ones_like(lb)
                eps = 1e-12
                unstable = (lb < 0) & (ub > 0)
                if unstable.any():
                    u = ub[unstable]
                    l = lb[unstable]
                    lam[unstable] = u / (u - l + eps)
                inactive = ub <= 0
                lam[inactive] = 0.0
                F = F * lam.unsqueeze(0)
            elif kind_s == "LRELU":
                bnds_fact = before.get(L.id)
                if bnds_fact is None:
                    F = None
                    break
                lb = bnds_fact.bounds.lb.flatten().to(device=device, dtype=dtype)
                ub = bnds_fact.bounds.ub.flatten().to(device=device, dtype=dtype)
                alpha = float(L.params.get("negative_slope", 0.01))
                if lb.numel() != F.shape[1]:
                    F = None
                    break
                eps = 1e-12
                lam = torch.ones_like(lb)
                unstable = (lb < 0) & (ub > 0)
                if unstable.any():
                    u = ub[unstable]; l = lb[unstable]
                    # triangle slope for leaky relu: between α and 1 depending on (l,u)
                    lam[unstable] = (u - alpha * l) / (u - l + eps)
                inactive = ub <= 0
                lam[inactive] = alpha
                F = F * lam.unsqueeze(0)
            elif kind_s in ("INPUT", "INPUT_SPEC"):
                # Don't update F; it's already at input space if reached.
                pass
            else:
                # Unsupported layer (CONV2D, ADD, CONCAT, MAXPOOL, BN, ...);
                # stop the chain. Earlier layers won't get F.
                if debug:
                    print(f"[spec_aware] chain stops at L{L.id} kind={kind_s}")
                F = None
                break
        except Exception as e:
            if debug:
                print(f"[spec_aware] exception at L{L.id} kind={kind_s}: {e!r}")
            F = None
            break

    return F_by_layer
